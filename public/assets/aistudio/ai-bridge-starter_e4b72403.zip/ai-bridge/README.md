# AI Bridge — universal AI-to-computer control (starter)

A security-first starter for connecting MCP-compatible AI clients to Linux and Windows machines.
This is an initial, deliberately limited implementation—not a remote root shell.

## What works in this starter
- MCP server using stdio transport.
- Read-only system information, disk usage, and directory listing constrained to a configured workspace.
- Fixed, predefined diagnostics (`uptime`, `df`, memory summary) without shell interpolation.
- An explicit task allowlist; no arbitrary shell command tool.
- Unit tests for path confinement and task validation.

## What is not implemented yet
- Remote device enrollment/control plane, OAuth, multi-tenant dashboard, Windows service/desktop automation.
- Production-grade identity, signed agent updates, approval UI, and remote transport.
- Automatic privileged operations. Do not expose this starter directly to the internet.

## Architecture

AI client (ChatGPT/Claude/Gemini/Codex where supported)
  -> MCP stdio server on the client machine
  -> tools in `src/ai_bridge/server.py`
  -> workspace-limited filesystem + fixed diagnostic tasks

For a remote Linux host, the recommended next stage is an outbound authenticated agent connection
(mTLS or short-lived device credentials) to a control plane. Do not expose an unrestricted shell.
The Windows helper should be a separate service with the same tool contract and OS-specific backend.

## Requirements
- Python 3.11+
- MCP Python SDK (`mcp`)
- Linux or Windows for local diagnostics; some diagnostics are Linux-only.

## Install on Linux
```bash
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip
git clone <your-repository-url> ai-bridge
cd ai-bridge
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
mkdir -p "$HOME/ai-bridge-workspace"
export AI_BRIDGE_WORKSPACE="$HOME/ai-bridge-workspace"
python -m ai_bridge.server
```

The server uses MCP stdio, so it normally stays running under the AI client. Do not run it as root.
For a quick check, run tests:
```bash
pip install -e ".[dev]"
pytest -q
```

## MCP client configuration example
Use the configuration format documented by your particular client. A common stdio-style shape is:
```json
{
  "mcpServers": {
    "ai-bridge": {
      "command": "/absolute/path/to/ai-bridge/.venv/bin/python",
      "args": ["-m", "ai_bridge.server"],
      "env": {
        "AI_BRIDGE_WORKSPACE": "/home/YOUR_USER/ai-bridge-workspace"
      }
    }
  }
}
```
On Windows, use the virtual environment's `Scripts\\python.exe` and a Windows workspace path.
Consumer web chat interfaces do not all support local stdio MCP servers; use the provider's supported connector/remote MCP path where available.

## Security model
- Run as an unprivileged account.
- The workspace root is the only file area exposed.
- File reads are text-only and size-limited.
- No arbitrary command execution, shell expansion, `sudo`, or writes in this starter.
- Diagnostic tasks are fixed commands, not user-provided command strings.
- Review every tool before enabling write/administrative actions.
- Treat all file contents and command output as untrusted input.
- Keep secrets, SSH private keys, cloud credentials, `.env` files, and production data outside the workspace.
